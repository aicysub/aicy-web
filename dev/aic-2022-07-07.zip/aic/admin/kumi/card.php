<?php
  include_once('/hdd/aic/head.php');
  ?>
<div class="none"> <a href="/admin/kumi/" style="display:block; border-radius:20px;"> <p class="nitro-history none" style="text-align:center;"><img src="/images/admins/kumi.png"> <span class="nomal" style="color:var(--main-text);">Eammes&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="hover" style="color:var(--main-text);">Eammes#3122</span><?php include('/hdd/aic/admin/admin-icon.php');?></p></a></div>