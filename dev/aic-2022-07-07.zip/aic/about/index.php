<?php
include('/hdd/aic/head.php');
ob_start();
?>
<title>About - あいしぃーのサーバー</title>
<div class="contents"><div class="main">
<br>
<h2 class="title h2">あいしぃーのサーバーについて</h2>
<p class="unei">雑談がメインのサーバーです！<br></p>
<p style="text-align: center; font-size: 15px;">このページの最終更新日：<?php date_default_timezone_set('asia/tokyo'); clearstatcache(); echo date( "Y/m/d H:i:s", filemtime(__FILE__)); ?></p>