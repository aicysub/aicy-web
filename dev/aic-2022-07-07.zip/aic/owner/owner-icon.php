<!DOCTYPE html>
<html lang="ja-JP">
  <?php
  include_once('/hdd/aic/head.php');
  ?>
  <span class="admins"><i class="fa-solid fa-star-shooting"></i> 鯖主</span>