<?php  include('/hdd/aic/head.php');?>
<ol itemscope class="bread none" itemtype="https://schema.org/BreadcrumbList">
  <li itemprop="itemListElement" itemscope
      itemtype="https://schema.org/ListItem">
    <a itemprop="item" href="/">
        <span itemprop="name">ホーム</span>
    </a>
    <meta itemprop="position" content="1" />
  </li>
  <li itemprop="itemListElement" itemscope
      itemtype="https://schema.org/ListItem">
    <a itemprop="item" href="/news/">
        <span itemprop="name">お知らせ</span>
    </a>
    <meta itemprop="position" content="2" />
  </li>
  <li itemprop="itemListElement" itemscope
  itemtype="https://schema.org/ListItem">
<a itemprop="item" href="/news/2022-05-11/">
    <span itemprop="name">サーバーブーストのお願い（2022/05/22）</span>
</a>
<meta itemprop="position" content="3" />
</li>
</ol>
<title>サーバーブーストのお願い - あいしぃーのさーばー</title>
<h2 class="h2 title">サーバーブーストのお願い</h2>
<blockquote class="box">
サーバーをブーストするとNitro配りの実施日程がわかるほか、<br>
ここのサーバーのイベントを考案することができます。<br>
その他にも サーバーブースター 向けのページをあいしぃーのサイトに載せようか検討中です。<br>
この機会にどうぞサーバーブーストをよろしくお願いいたします。<br>
<p style="text-align: right;"><a href="https://discord.com/channels/949560203374915605/957605381029363822/977915990337785967" target="_blank">2022/05/22</a></p>
<p class="none" style="text-align: right;margin-top: 15px;" >投稿者： <a href="/admin/ryouma/" class="none" ><img  src="/images/admins/ryouma.png" style="vertical-align:sub;" class="icon-img" width="30">りょうま<?php include('/hdd/aic/admin/admin-icon.php');?></a></p>
</blockquote>
<div class="news-messeage">
2022/05/22時点の情報となります。<br>
現在の状況とは異なる場合がございます。
</div>