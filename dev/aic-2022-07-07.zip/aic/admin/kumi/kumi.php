<?php
include_once('/hdd/aic/head.php');
ob_start();
?>
<div class="name-list none" id="kumi"><a href="/admin/kumi/">
    <h3 class="name"><img src="/images/admins/kumi.png" style="width: 20%;border-radius: 50%;align-items: center; margin-right: 5%;  border: 3px solid #906862; border-radius: 50%; box-shadow: 0 3px 3px rgb(0 0 0/12%),0 2px 3px -2px rgb(0 0 0/1%); background: #fff;">⭐クミ<br><p style="display: contents;font-size: 15px;">とっても元気な子</p></h3><br>
       <p class="description">クミです。呼び方はなんでもよし！<br>実はDiscordServerをたくさん所有してる人です。<br>よろし～く
   </div></a>