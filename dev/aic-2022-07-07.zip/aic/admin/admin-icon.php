<!DOCTYPE html>
<html lang="ja-JP">
  <?php
  include_once('/hdd/aic/head.php');
  ?>
<span class="admins"><i class="fa-solid fa-circle-check"></i> 運営</span>