<?php include_once("/hdd/aic/head.html");
ob_start();
?>
<h2 class="title" style="text-align:center;">未記入項目があるので表示できませんでした。</h2>
<?php include("/hdd/aic/404.php");