<?php
require('/hdd/aic/head.html');
?>
<div class="contents">
    <title>LINE（笑） - あいしぃーのさーばー</title>
<div class="main">
<div style="padding: 65px;background-image: url(/images/qr.png);background-repeat: no-repeat;height: fit-content;position: absolute; top: 50%; left: 50%; -webkit-transform: translate(-50%, -50%); transform: translate(-50%, 140%) scale(3);">
<div class="hide" style="inset: 0px; z-index: 100; opacity: 1; pointer-events: all; background-color: rgba(0, 0, 0, 0); filter: blur(0px);"><img src="/images/LINE.png" width="60">
<div class="modals" id="modals">