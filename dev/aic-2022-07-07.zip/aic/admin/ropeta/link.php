<!DOCTYPE html>
<html lang="ja-JP">
  <?php
  include_once('/hdd/aic/head.php');
  ?>
<div class="link">
    <a class="link-a" href="https://www.twitch.tv/lo_pu_ta" target="_blank">
        <i class="fa-brands fa-twitch"></i> lo_pu_ta</a>
    <a class="link-a" href="https://twitter.com/furagame_lo_pu" target="_blank">
        <i class="fa-brands fa-twitter"></i> ぜったいれいど</a>
    </div>