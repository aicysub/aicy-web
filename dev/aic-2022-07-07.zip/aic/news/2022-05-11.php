<?php 
include_once("/hdd/aic/head.php");
?>
<ol itemscope class="bread none" itemtype="https://schema.org/BreadcrumbList">
  <li itemprop="itemListElement" itemscope
      itemtype="https://schema.org/ListItem">
    <a itemprop="item" href="/">
        <span itemprop="name">ホーム</span>
    </a>
    <meta itemprop="position" content="1" />
  </li>
  <li itemprop="itemListElement" itemscope
      itemtype="https://schema.org/ListItem">
    <a itemprop="item" href="/news/">
        <span itemprop="name">お知らせ</span>
    </a>
    <meta itemprop="position" content="2" />
  </li>
  <li itemprop="itemListElement" itemscope
  itemtype="https://schema.org/ListItem">
<a itemprop="item" href="/news/2022-05-11/">
    <span itemprop="name">浮上率低下による臨時最高責任者の制定（2022/05/11）</span>
</a>
<meta itemprop="position" content="3" />
</li>
</ol>
<title>浮上率低下による臨時最高責任者の制定 - あいしぃーのさーばー</title>
<h2 class="h2 title">浮上率低下による臨時最高責任者の制定</h2>
<blockquote class="box">
2022/05/12から何日か浮上できない日が多くなるぞ<br>
よろしくね<br>
<a href="/admin/">@運営</a>に任せます<br>
臨時最高責任者は <a href="/admin/papurusuta/">@ぱぷるすた</a> と <a href="/admin/edamame/">@えだまめっ！</a> です。
<p style="text-align: right;"><a href="https://discord.com/channels/949560203374915605/957605381029363822/973931994801119344" target="_blank">2022/05/11</a></p>
<p class="none" style="text-align: right;margin-top: 15px;">投稿者： <a href="https://aic-group.sytes.net/owner/aicy/" class="none"><img src="/favicon.ico" style="vertical-align:sub;" class="icon-img" width="30">あいしぃー<?php require("/hdd/aic/owner/owner-icon.php");?></a></p>
</blockquote>
<div class="news-messeage">
2022/05/11時点の情報となります。<br>
現在の状況とは異なる場合がございます。
</div>