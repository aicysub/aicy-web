<?php
include_once('/hdd/aic/head.php');
ob_start();
?>
<div class="name-list none" id="nemoyans"><a href="/admin/gijutsu/">
       <h3 class="name"><img src="/images/admins/gijutsu.png" style="width: 20%;border-radius: 50%;align-items: center; margin-right: 5%;  border: 3px solid #906862; border-radius: 50%; box-shadow: 0 3px 3px rgb(0 0 0/12%),0 2px 3px -2px rgb(0 0 0/1%); background: #fff;">技術<br><p style="display: contents;font-size: 15px;">ガキ</p></h3><br>
       <p class="description">どうも技術です<br>無能ですがモデレーター歴あります<br>アイコンは最近やってないフォートナイトのキャラクターです</p>
   </div></a>