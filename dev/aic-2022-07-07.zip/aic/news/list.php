<?php
include_once('/hdd/aic/head.html');
?>
<div class="contents">
<div class="main">
    <h2 class="title h2">最新のお知らせ</h2>