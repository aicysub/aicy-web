<?php
include_once('/hdd/aic/head.php');
?>
<script>
      setTimeout(function(){loadCSS( '/css/dark.php?version=3.1.3', document.getElementById('loadcss') );},500);
      document.cookie = 'dark=true; max-age=0'; 
      document.cookie = 'dark=true; max-age=0';
      document.cookie = 'dark=true; max-age=0';
document.cookie = 'dark=true';
document.cookie = 'access=true';
  document.cookie = 'white=true; max-age=0'; 
  $('#setup').attr('url','/');
  setup_modal();
  $('#modals').fadeIn(1000);
    </script>
    <title>セットアップ - あいしぃーのさーばー</title>
<div class="modals" id="modals">