<?php
  include_once('/hdd/aic/head.php');
  ?>
<div class="none"> <a href="/admin/papurusuta/" style="display:block; border-radius:20px;"> <p class="nitro-history none" style="text-align:center;"><img src="/images/admins/papurusuta.png"> <span class="nomal" style="color:var(--main-text);">papurusuta&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="hover" style="color:var(--main-text);">papurusuta#0901</span><?php include('/hdd/aic/admin/admin-icon.php');?></p></a></div>