<!DOCTYPE html>
<html lang="ja-JP">
  <?php
  include_once('/hdd/aic/head.php');
  ?>
<div class="link">
    <a class="link-a" href="https://www.twitch.tv/papurusuta" target="_blank">
        <i class="fa-brands fa-twitch"></i> papurusuta</a>
    <a class="link-a" href="https://twitter.com/papurusuta" target="_blank">
        <i class="fa-brands fa-twitter"></i> papurusuta</a>
    </div>