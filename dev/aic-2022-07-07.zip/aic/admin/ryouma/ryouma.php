<?php
include_once('/hdd/aic/head.php');
ob_start();
?>
<div class="name-list none" id="ryouma"><a href="/admin/ryouma/">
    <h3 class="name"><img src="/images/admins/ryouma.png" style="width: 20%;border-radius: 50%;align-items: center; margin-right: 5%;  border: 3px solid #906862; border-radius: 50%; box-shadow: 0 3px 3px rgb(0 0 0/12%),0 2px 3px -2px rgb(0 0 0/1%); background: #fff;">りょうま<br><p style="display: contents;font-size: 15px;">最近181cmになりました。うぇーい</p></h3><br>
 <p class="description">どうもりょうまです。<br>こんなんでも一応社長です。<br>よろしく。27歳</div></a>   