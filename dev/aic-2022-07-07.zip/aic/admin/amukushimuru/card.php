<?php
  include_once('/hdd/aic/head.php');
  ?>
<div class="none"> <a href="/admin/amukushimuru/" style="display:block; border-radius:20px;"> <p class="nitro-history none" style="text-align:center;"><img src="/images/admins/amukushimuru.png"> <span class="nomal" style="color:var(--main-text);">アムクシル2&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="hover" style="color:var(--main-text);">アムクシル2#3781</span><?php include('/hdd/aic/admin/admin-icon.php');?></p></a></div>