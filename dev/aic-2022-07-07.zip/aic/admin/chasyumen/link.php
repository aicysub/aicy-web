<!DOCTYPE html>
<html lang="ja-JP">
<?php
include_once('/hdd/aic/head.php');
?>
<div class="link">
    <a class="link-a" href="https://github.com/chasyumen" target="_blank">
        <i class="fa-brands fa-github"></i> chasyumen</a>
    <a class="link-a" href="https://github.com/chasyumen" target="_blank">
        <i class="fa-brands fa-reddit"></i> chasyumens</a>
   <a class="link-a" href="https://open.spotify.com/user/mbn9cy86itnuwm819dsayr9w7" target="_blank">
    <i class="fa-brands fa-spotify"></i> chasyumens</a>
    <a class="link-a" href="https://steamcommunity.com/id/chasyumen/" target="_blank">
        <i class="fa-brands fa-steam"></i> chasyumens</a>
    <a class="link-a" href="https://www.twitch.tv/chasyumens" target="_blank">
        <i class="fa-brands fa-steam"></i> chasyumens</a>
    <a class="link-a" href="https://twitter.com/chasyumens" target="_blank">
        <i class="fa-brands fa-twitter"></i> chasyumens</a>
    <a class="link-a" href="https://twitter.com/sub_chasyumens" target="_blank">
        <i class="fa-brands fa-twitter"></i> chasyumens2@相互フォロー</a>
    <a class="link-a" href="https://www.youtube.com/channel/UCuxlWuJcZG0kTMjAaWt_Sjw" target="_blank">
        <i class="fa-brands fa-youtube"></i> chasyumens</a>
    <a class="link-a" href="https://www.youtube.com/channel/UCinYtuEr4V1jTBPVFkBfvKA" target="_blank">
        <i class="fa-brands fa-youtube"></i> chasyumens2</a>
    </div>