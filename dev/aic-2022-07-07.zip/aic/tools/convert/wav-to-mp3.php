
<?php
include('/hdd/aic/head.html');
if(!isset($_GET['wav'])){
    echo '
    <div class="hide" style="inset: 0px; z-index: 100; opacity: 1; pointer-events: all; background-color: rgba(0, 0, 0, 0); filter: blur(0px);">
    <div class="contents">
    <style>
  #etc {
    background-color: var(--nav-focus);
    color: var(--main-text);
    transform: scale(1.05);
  }
  #youtube {
    background-color: var(--nav-focus);
    color: var(--main-text);
    transform: scale(1.05);
    pointer-events: none;
  }
  #etc i,#youtube i {
    color: var(--main-text);
  }
  </style>
    <div class="main">
    <title>エラーが発生しました。 - あいしぃーのサーバー</title>
    <h2 class="h2 title">やり直す</h2>';
    include '/hdd/aic/edit.php';
    echo '
    <div class="box">
    <form action="/tools/wav" style="text-align: center;" method="post">
    <input type="file" class="download" name="upload" accept="audio/wav" required>
        <input type="submit" class="download" id="upload" value="アップロード" required>
    </form>
    <br>
    <p style="text-align:center;">ファイルが正しくアップロードされていないか、拡張子の選択が誤っています。<br>お手数ですが、再度やり直してください。</p>
    </div>
    </div>
    </div>
    ';
return FALSE;
}else{
    $link = $_GET['v'];
}