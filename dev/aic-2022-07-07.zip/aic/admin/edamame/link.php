<!DOCTYPE html>
<html lang="ja-JP">
  <?php
  include_once('/hdd/aic/head.php');
  ?>
<div class="link">
    <a class="link-a" href="https://open.spotify.com/user/31za3avlhb2kqeeel5ddnvikiejy" target="_blank">
        <i class="fa-brands fa-spotify"></i> えだまめ</a>
    <a class="link-a" href="https://twitter.com/Beans_MSE" target="_blank">
        <i class="fa-brands fa-twitter"></i> えだまめっ！💡</a>
    <a class="link-a" href="https://www.youtube.com/channel/UCliiRbK3u0a8c47Z-L2AZHA" target="_blank">
        <i class="fa-brands fa-youtube"></i> えだまめ</a>
    </div>