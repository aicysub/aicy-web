  <?php
  include_once('/hdd/aic/head.php');
  ?>
<div class="none"> <a href="/owner/aicy/" style="display:block; border-radius:20px;"> <p class="nitro-history none" style="text-align:center;"><img src="/favicon.ico"> <span class="nomal" style="color:var(--main-text);">!!.あいしぃー&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span class="hover" style="color:var(--main-text);">!!.あいしぃー#6301</span><?php include('/hdd/aic/owner/owner-icon.php');include('/hdd/aic/admin/admin-icon.php');?></p></a></div>